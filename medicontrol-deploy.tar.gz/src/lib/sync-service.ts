import type { Medication, DoseRecord, UserProfile, Caregiver, CaregiverAlert } from '@/types/medication';
import type { User, Caregiver as AuthCaregiver } from '@/types/auth';

// Sync status type
export type SyncStatus = 'idle' | 'syncing' | 'error' | 'offline';

// Sync state for tracking
export interface SyncState {
  status: SyncStatus;
  lastSyncAt: string | null;
  error: string | null;
  pendingChanges: number;
}

// Check if we're online and Supabase is configured
export async function canSync(): Promise<boolean> {
  if (typeof window !== 'undefined' && !navigator.onLine) {
    return false;
  }
  
  try {
    const response = await fetch('/api/sync/user', { 
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });
    return response.ok || response.status === 401; // 401 means configured but not logged in
  } catch {
    return false;
  }
}

// Check if user is authenticated with Supabase
export async function isAuthenticatedWithSupabase(): Promise<boolean> {
  try {
    const response = await fetch('/api/sync/user', { 
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });
    return response.ok;
  } catch {
    return false;
  }
}

// Sync medications with cloud
export async function syncMedicationsToCloud(medications: Medication[]): Promise<{
  success: boolean;
  medications?: Medication[];
  error?: string;
}> {
  try {
    const response = await fetch('/api/sync/medications', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });

    if (!response.ok) {
      const errorData = await response.json();
      return { success: false, error: errorData.error || 'Failed to sync' };
    }

    const data = await response.json();
    return { success: true, medications: data.medications };
  } catch (error) {
    console.error('Error syncing medications:', error);
    return { success: false, error: 'Network error' };
  }
}

// Create medication in cloud
export async function createMedicationInCloud(
  medication: Omit<Medication, 'id' | 'createdAt' | 'updatedAt'>
): Promise<{ success: boolean; medication?: Medication; error?: string }> {
  try {
    const response = await fetch('/api/sync/medications', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ medication })
    });

    if (!response.ok) {
      const errorData = await response.json();
      return { success: false, error: errorData.error || 'Failed to create' };
    }

    const data = await response.json();
    return { success: true, medication: data.medication };
  } catch (error) {
    console.error('Error creating medication:', error);
    return { success: false, error: 'Network error' };
  }
}

// Update medication in cloud
export async function updateMedicationInCloud(
  id: string,
  updates: Partial<Medication>
): Promise<{ success: boolean; medication?: Medication; error?: string }> {
  try {
    const response = await fetch('/api/sync/medications', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, updates })
    });

    if (!response.ok) {
      const errorData = await response.json();
      return { success: false, error: errorData.error || 'Failed to update' };
    }

    const data = await response.json();
    return { success: true, medication: data.medication };
  } catch (error) {
    console.error('Error updating medication:', error);
    return { success: false, error: 'Network error' };
  }
}

// Delete medication from cloud
export async function deleteMedicationFromCloud(
  id: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const response = await fetch(`/api/sync/medications?id=${id}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' }
    });

    if (!response.ok) {
      const errorData = await response.json();
      return { success: false, error: errorData.error || 'Failed to delete' };
    }

    return { success: true };
  } catch (error) {
    console.error('Error deleting medication:', error);
    return { success: false, error: 'Network error' };
  }
}

// Sync dose records with cloud
export async function syncDoseRecordsToCloud(
  startDate?: string,
  endDate?: string
): Promise<{ success: boolean; doseRecords?: DoseRecord[]; error?: string }> {
  try {
    const params = new URLSearchParams();
    if (startDate) params.set('startDate', startDate);
    if (endDate) params.set('endDate', endDate);
    
    const response = await fetch(`/api/sync/doses?${params.toString()}`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });

    if (!response.ok) {
      const errorData = await response.json();
      return { success: false, error: errorData.error || 'Failed to sync' };
    }

    const data = await response.json();
    return { success: true, doseRecords: data.doseRecords };
  } catch (error) {
    console.error('Error syncing dose records:', error);
    return { success: false, error: 'Network error' };
  }
}

// Create dose record in cloud
export async function createDoseRecordInCloud(
  doseRecord: Omit<DoseRecord, 'id' | 'createdAt'>
): Promise<{ success: boolean; doseRecord?: DoseRecord; error?: string }> {
  try {
    const response = await fetch('/api/sync/doses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ doseRecord })
    });

    if (!response.ok) {
      const errorData = await response.json();
      return { success: false, error: errorData.error || 'Failed to create' };
    }

    const data = await response.json();
    return { success: true, doseRecord: data.doseRecord };
  } catch (error) {
    console.error('Error creating dose record:', error);
    return { success: false, error: 'Network error' };
  }
}

// Update dose record in cloud
export async function updateDoseRecordInCloud(
  id: string,
  updates: Partial<DoseRecord>
): Promise<{ success: boolean; doseRecord?: DoseRecord; error?: string }> {
  try {
    const response = await fetch('/api/sync/doses', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, updates })
    });

    if (!response.ok) {
      const errorData = await response.json();
      return { success: false, error: errorData.error || 'Failed to update' };
    }

    const data = await response.json();
    return { success: true, doseRecord: data.doseRecord };
  } catch (error) {
    console.error('Error updating dose record:', error);
    return { success: false, error: 'Network error' };
  }
}

// Batch sync dose records (for offline sync)
export async function batchSyncDoseRecords(
  doseRecords: DoseRecord[]
): Promise<{ success: boolean; count?: number; error?: string }> {
  try {
    const response = await fetch('/api/sync/doses', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ doseRecords })
    });

    if (!response.ok) {
      const errorData = await response.json();
      return { success: false, error: errorData.error || 'Failed to sync' };
    }

    const data = await response.json();
    return { success: true, count: data.count };
  } catch (error) {
    console.error('Error batch syncing dose records:', error);
    return { success: false, error: 'Network error' };
  }
}

// Sync user profile with cloud
export async function syncUserFromCloud(): Promise<{
  success: boolean;
  user?: User;
  profile?: UserProfile;
  error?: string;
}> {
  try {
    const response = await fetch('/api/sync/user', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });

    if (!response.ok) {
      const errorData = await response.json();
      return { success: false, error: errorData.error || 'Failed to sync' };
    }

    const data = await response.json();
    return { success: true, user: data.user, profile: data.profile };
  } catch (error) {
    console.error('Error syncing user:', error);
    return { success: false, error: 'Network error' };
  }
}

// Create user in cloud
export async function createUserInCloud(
  name: string,
  email: string,
  phone?: string
): Promise<{ success: boolean; user?: User; error?: string }> {
  try {
    const response = await fetch('/api/sync/user', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, phone })
    });

    if (!response.ok) {
      const errorData = await response.json();
      return { success: false, error: errorData.error || 'Failed to create' };
    }

    const data = await response.json();
    return { success: true, user: data.user };
  } catch (error) {
    console.error('Error creating user:', error);
    return { success: false, error: 'Network error' };
  }
}

// Update user in cloud
export async function updateUserInCloud(
  userUpdates?: Partial<User>,
  profileUpdates?: Partial<UserProfile>
): Promise<{ success: boolean; error?: string }> {
  try {
    const response = await fetch('/api/sync/user', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userUpdates, profileUpdates })
    });

    if (!response.ok) {
      const errorData = await response.json();
      return { success: false, error: errorData.error || 'Failed to update' };
    }

    return { success: true };
  } catch (error) {
    console.error('Error updating user:', error);
    return { success: false, error: 'Network error' };
  }
}

// Add caregiver to cloud
export async function addCaregiverToCloud(
  caregiver: Omit<AuthCaregiver, 'id' | 'createdAt'>
): Promise<{ success: boolean; caregiver?: AuthCaregiver; error?: string }> {
  try {
    const response = await fetch('/api/sync/user', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'add', caregiver })
    });

    if (!response.ok) {
      const errorData = await response.json();
      return { success: false, error: errorData.error || 'Failed to add' };
    }

    const data = await response.json();
    return { success: true, caregiver: data.caregiver };
  } catch (error) {
    console.error('Error adding caregiver:', error);
    return { success: false, error: 'Network error' };
  }
}

// Update caregiver in cloud
export async function updateCaregiverInCloud(
  caregiverId: string,
  updates: Partial<AuthCaregiver>
): Promise<{ success: boolean; caregiver?: AuthCaregiver; error?: string }> {
  try {
    const response = await fetch('/api/sync/user', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'update', caregiverId, updates })
    });

    if (!response.ok) {
      const errorData = await response.json();
      return { success: false, error: errorData.error || 'Failed to update' };
    }

    const data = await response.json();
    return { success: true, caregiver: data.caregiver };
  } catch (error) {
    console.error('Error updating caregiver:', error);
    return { success: false, error: 'Network error' };
  }
}

// Delete caregiver from cloud
export async function deleteCaregiverFromCloud(
  caregiverId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const response = await fetch('/api/sync/user', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'delete', caregiverId })
    });

    if (!response.ok) {
      const errorData = await response.json();
      return { success: false, error: errorData.error || 'Failed to delete' };
    }

    return { success: true };
  } catch (error) {
    console.error('Error deleting caregiver:', error);
    return { success: false, error: 'Network error' };
  }
}

// Full sync - sync all data from cloud
export async function fullSync(): Promise<{
  success: boolean;
  medications?: Medication[];
  doseRecords?: DoseRecord[];
  user?: User;
  profile?: UserProfile;
  error?: string;
}> {
  try {
    // Check if we can sync
    const authed = await isAuthenticatedWithSupabase();
    if (!authed) {
      return { success: false, error: 'Not authenticated' };
    }

    // Sync medications
    const medsResult = await syncMedicationsToCloud([]);
    
    // Sync dose records (last 30 days)
    const today = new Date();
    const thirtyDaysAgo = new Date(today);
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const dosesResult = await syncDoseRecordsToCloud(
      thirtyDaysAgo.toISOString().split('T')[0],
      today.toISOString().split('T')[0]
    );

    // Sync user
    const userResult = await syncUserFromCloud();

    return {
      success: true,
      medications: medsResult.medications,
      doseRecords: dosesResult.doseRecords,
      user: userResult.user,
      profile: userResult.profile,
    };
  } catch (error) {
    console.error('Error in full sync:', error);
    return { success: false, error: 'Sync failed' };
  }
}

// Pending changes queue for offline support
const PENDING_CHANGES_KEY = 'medicontrol-pending-changes';

interface PendingChange {
  id: string;
  type: 'medication' | 'dose' | 'user' | 'caregiver';
  action: 'create' | 'update' | 'delete';
  data: unknown;
  timestamp: string;
}

export function getPendingChanges(): PendingChange[] {
  if (typeof window === 'undefined') return [];
  const stored = localStorage.getItem(PENDING_CHANGES_KEY);
  return stored ? JSON.parse(stored) : [];
}

export function addPendingChange(
  type: PendingChange['type'],
  action: PendingChange['action'],
  data: unknown
): void {
  if (typeof window === 'undefined') return;
  
  const changes = getPendingChanges();
  changes.push({
    id: `${type}-${action}-${Date.now()}`,
    type,
    action,
    data,
    timestamp: new Date().toISOString(),
  });
  
  localStorage.setItem(PENDING_CHANGES_KEY, JSON.stringify(changes));
}

export function removePendingChange(id: string): void {
  if (typeof window === 'undefined') return;
  
  const changes = getPendingChanges();
  const filtered = changes.filter(c => c.id !== id);
  localStorage.setItem(PENDING_CHANGES_KEY, JSON.stringify(filtered));
}

export function clearPendingChanges(): void {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(PENDING_CHANGES_KEY);
}

// Process pending changes when back online
export async function processPendingChanges(): Promise<{
  success: boolean;
  processed: number;
  failed: number;
}> {
  const changes = getPendingChanges();
  let processed = 0;
  let failed = 0;

  for (const change of changes) {
    try {
      let result: { success: boolean } = { success: false };

      switch (change.type) {
        case 'medication':
          switch (change.action) {
            case 'create':
              result = await createMedicationInCloud(change.data as Omit<Medication, 'id' | 'createdAt' | 'updatedAt'>);
              break;
            case 'update':
              const updateData = change.data as { id: string; updates: Partial<Medication> };
              result = await updateMedicationInCloud(updateData.id, updateData.updates);
              break;
            case 'delete':
              result = await deleteMedicationFromCloud(change.data as string);
              break;
          }
          break;

        case 'dose':
          switch (change.action) {
            case 'create':
              result = await createDoseRecordInCloud(change.data as Omit<DoseRecord, 'id' | 'createdAt'>);
              break;
            case 'update':
              const updateData = change.data as { id: string; updates: Partial<DoseRecord> };
              result = await updateDoseRecordInCloud(updateData.id, updateData.updates);
              break;
          }
          break;

        case 'user':
          if (change.action === 'update') {
            const userData = change.data as { userUpdates?: Partial<User>; profileUpdates?: Partial<UserProfile> };
            result = await updateUserInCloud(userData.userUpdates, userData.profileUpdates);
          }
          break;

        case 'caregiver':
          switch (change.action) {
            case 'add':
              result = await addCaregiverToCloud(change.data as Omit<AuthCaregiver, 'id' | 'createdAt'>);
              break;
            case 'update':
              const cgData = change.data as { id: string; updates: Partial<AuthCaregiver> };
              result = await updateCaregiverInCloud(cgData.id, cgData.updates);
              break;
            case 'delete':
              result = await deleteCaregiverFromCloud(change.data as string);
              break;
          }
          break;
      }

      if (result.success) {
        removePendingChange(change.id);
        processed++;
      } else {
        failed++;
      }
    } catch {
      failed++;
    }
  }

  return { success: failed === 0, processed, failed };
}
